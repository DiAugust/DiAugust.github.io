# DiAugust.github.io

Meu portfólio profissional é atualizado sempre que aprendo uma nova stack, dessa forma consigo compartilhar quais tecnologias estou usando atualmente e/ou aprendendo e testando. Nele também é possível ver os projetos em que participo ou participei.

Atualmente o projeto é composto por:

 - HTML
 - CSS
 - Javascript

Faço o uso das bibliotecas:
[AOS](https://michalsnik.github.io/aos/) (Animate On Scroll Library), para animações em CSS que são ativadas via scroll. 
[Ionicons](https://ionicons.com/), para definir um padrão de icones usando material design.

Responsividade do site usando **media query** e **flexbox**.
